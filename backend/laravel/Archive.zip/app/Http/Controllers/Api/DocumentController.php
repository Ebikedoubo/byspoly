<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;

class DocumentController extends Controller
{
    //
}
