<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;

class ApplicationFeePaymentController extends Controller
{
    //
}
